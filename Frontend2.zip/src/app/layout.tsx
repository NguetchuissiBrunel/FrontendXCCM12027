// src/app/layout.tsx
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import RouteLoading from '@/components/ui/RouteLoading'; 
import './globals.css';


const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'XCCM1 - Plateforme de création de contenu pédagogique',
  description: 'Créez, organisez et partagez vos contenus pédagogiques de manière intuitive avec XCCM1',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fr">
      <body className={inter.className}>
        <div className="min-h-screen flex flex-col">
       
          <main className="grow">
            <RouteLoading/>
            {children}
          </main>
        
        </div>
      </body>
    </html>
  );
}